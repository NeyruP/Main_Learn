#========================
#------ PLAYER ---------
#========================
 
class Player:

    def __init__(self, name, class_name='Guerreiro'):
        self.name = name
        self.class_name = class_name if class_name in CLASS_DEFS else 'Guerreiro'
        class_data = CLASS_DEFS[self.class_name]
        self.attributes = class_data['attributes'].copy()
        self.attribute_points = 0
        self.max_health = class_data['max_health']
        self.health = self.max_health
        self.max_mana = class_data['max_mana']
        self.mana = self.max_mana
        self.crit_chance = 5
        self.status_effects = []
        self.skill_tree = []
        self.known_skills = ['Golpe de Mana']
        if class_data['starting_skill'] not in self.known_skills:
            self.known_skills.append(class_data['starting_skill'])
        self.money = 50
        self.weapon = 'Punhos'
        self.weapon_level = 1
        self.level = 1
        self.exp = 0
        self.exp_to_next = 50
        # [SISTEMA DE ARMADURA] - Atributo inicial
        self.armor = None
        self.inventory = {
            'pocoes': 1,
            'cabecas_boss': [],
            'drops': {},  # armazenamento para drops (pele, veneno, etc.)
        }
 
        self.skills = [

            {'nome': 'Golpe de Mana', 'custo': 10}
        ]
 
        # Companion
        self.pet = None
        # Quests
        self.active_quests = []  # stores quest dicts with progress
        self.completed_quests = []
        # Achievements
        self.achievements = {}
    def display_status(self):

        # [SISTEMA DE ARMADURA] - status
        armor_name = self.armor['nome'] if self.armor else 'Nenhuma'
        armor_lvl = f" (Nív. {self.armor.get('level', 1)})" if self.armor else ""
        dur = f"{self.armor['durabilidade']}/{self.armor['max_durabilidade']}" if self.armor else '0/0'
        pet_name = f' | 🐾 {self.pet.name} Lv{self.pet.level}' if self.pet else ''
        ach_count = len(self.achievements)

        # >>> Correção: definir status_text antes de usar no print
        status_text = ', '.join([e.get('name', '') for e in self.status_effects]) if self.status_effects else 'Nenhum'

        print(

            f'\n👤 {self.name} | LVL {self.level} | '
            f'❤️ {self.health}/{self.max_health} | '
            f'✨ {self.mana}/{self.max_mana} | '
            f'💰 {self.money}g\n'
            f'⚔️ {self.weapon} Lvl.{self.weapon_level} | '
            f'🛡️ {armor_name}{armor_lvl} (Dur: {dur}){pet_name} | 🏆 {ach_count}\n'
            f'💥 Crítico: {self.crit_chance:.1f}% | 📈 Pontos: {self.attribute_points} | '
            f'☠️ Status: {status_text}'
        )
 
    def gain_exp(self, amount):
        self.exp += amount
        print(f'✨ +{amount} EXP')
        while self.exp >= self.exp_to_next:
            self.exp -= self.exp_to_next
            self.level += 1
            self.exp_to_next = int(self.exp_to_next * 1.25)
            self.attribute_points += 2
            old_max_health = self.max_health
            old_max_mana = self.max_mana
            recalcular_estatisticas(self)
            self.health = self.max_health
            self.mana = self.max_mana
            slow_print(f'🎉 LEVEL UP {self.level}! +2 pontos de atributo')
            if self.level >= 3:
                skill_tree_menu(self)
        # pet gets a bit of exp when player levels or gains exp
        if self.pet:
            self.pet.gain_exp(int(amount / 4))
    def add_drop(self, item, count=1):
        self.inventory['drops'][item] = self.inventory['drops'].get(item, 0) + count
    def check_quests_progress(self, enemy_name=None, drop_item=None, boss_killed=False):
        for q in list(self.active_quests):
            prog = q.setdefault('progress', 0)
            target = q['target']
            updated = False
            if 'enemy_name' in target and enemy_name == target['enemy_name']:
                q['progress'] = prog + 1
                updated = True
            if 'item' in target and drop_item == target['item']:
                # A missão acompanha a quantidade realmente obtida no inventário.
                available = self.inventory.get('drops', {}).get(drop_item, 0)
                q['progress'] = min(available, target.get('count', 1))
                updated = True
            if 'boss' in target and boss_killed and target['boss']:
                q['progress'] = prog + 1
                updated = True
            if updated:

                print(f'📜 Progresso da missão "{q["titulo"]}": {q["progress"]}/{target.get("count",1)}')

                if q['progress'] >= target.get('count', 1):

                    # complete

                    self.money += q['recompensa_money']
                    self.gain_exp(q['recompensa_exp'])
                    print(f'🏁 Missão completa: {q["titulo"]}! +{q["recompensa_money"]}g +{q["recompensa_exp"]} EXP')
                    self.completed_quests.append(q)
                    self.active_quests.remove(q)

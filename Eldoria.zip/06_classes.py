#========================
#------ CLASSES / ATRIBUTOS
#========================

CLASS_DEFS = {
    'Guerreiro': {
        'max_health': 125, 'max_mana': 40,
        'attributes': {'forca': 8, 'destreza': 5, 'constituicao': 8,
                       'inteligencia': 3, 'sabedoria': 4, 'sorte': 5},
        'starting_skill': 'Golpe Poderoso'
    },
    'Mago': {
        'max_health': 85, 'max_mana': 85,
        'attributes': {'forca': 3, 'destreza': 4, 'constituicao': 4,
                       'inteligencia': 9, 'sabedoria': 7, 'sorte': 5},
        'starting_skill': 'Bola Arcana'
    },
    'Ladino': {
        'max_health': 100, 'max_mana': 50,
        'attributes': {'forca': 6, 'destreza': 9, 'constituicao': 5,
                       'inteligencia': 5, 'sabedoria': 4, 'sorte': 8},
        'starting_skill': 'Ataque Furtivo'
    },
    'Paladino': {
        'max_health': 115, 'max_mana': 60,
        'attributes': {'forca': 7, 'destreza': 4, 'constituicao': 8,
                       'inteligencia': 4, 'sabedoria': 8, 'sorte': 4},
        'starting_skill': 'Golpe Sagrado'
    }
}

SKILL_DEFS = {
    'Golpe de Mana': {'custo': 10, 'tipo': 'magia', 'dano': 25, 'escala': 'inteligencia'},
    'Golpe Poderoso': {'custo': 8, 'tipo': 'fisico', 'dano': 30, 'escala': 'forca'},
    'Bola Arcana': {'custo': 12, 'tipo': 'magia', 'dano': 38, 'escala': 'inteligencia'},
    'Ataque Furtivo': {'custo': 10, 'tipo': 'fisico', 'dano': 28, 'escala': 'destreza'},
    'Golpe Sagrado': {'custo': 12, 'tipo': 'magia', 'dano': 32, 'escala': 'sabedoria'},
    'Escudo Solar': {'custo': 15, 'tipo': 'hibrido', 'dano': 18, 'escala': 'sabedoria'},
    'Explosão Estelar': {'custo': 25, 'tipo': 'magia', 'dano': 55, 'escala': 'inteligencia'},
    'Golpe Brutal': {'custo': 18, 'tipo': 'fisico', 'dano': 60, 'escala': 'forca'},
    'Passo Sombrio': {'custo': 15, 'tipo': 'fisico', 'dano': 35, 'escala': 'destreza'},
}

SKILL_TREE = {
    'Golpe Poderoso': [('Golpe Brutal', 3)],
    'Bola Arcana': [('Explosão Estelar', 5)],
    'Ataque Furtivo': [('Passo Sombrio', 3)],
    'Golpe Sagrado': [('Escudo Solar', 3)],
    'Golpe de Mana': [('Escudo Solar', 3)],
}

STATUS_DEFS = {
    'veneno': {'turns': 3, 'damage': 5},
    'sangramento': {'turns': 3, 'damage': 4},
    'queimando': {'turns': 2, 'damage': 8},
    'atordoado': {'turns': 1, 'skip': True},
    'fúria': {'turns': 3, 'damage_bonus': 0.5},
}

def escolher_classe():
    print('\n════════ ESCOLHA SUA CLASSE ════════')
    nomes = list(CLASS_DEFS)
    for i, nome in enumerate(nomes, 1):
        d = CLASS_DEFS[nome]
        print(f'{i}. {nome} | ❤️ {d["max_health"]} | 💙 {d["max_mana"]}')
    while True:
        try:
            escolha = int(input('> '))
            if 1 <= escolha <= len(nomes):
                return nomes[escolha - 1]
        except ValueError:
            pass
        print('❌ Escolha inválida.')

def recalcular_estatisticas(p):
    a = p.attributes
    p.max_health = 100 + a['constituicao'] * 5 + (p.level - 1) * 15
    p.max_mana = 30 + a['inteligencia'] * 4 + a['sabedoria'] * 2 + (p.level - 1) * 10
    p.crit_chance = min(50, 5 + a['destreza'] * 1.5 + a['sorte'] * 0.75)

def mostrar_atributos(p):
    print('\n════════ ATRIBUTOS ════════')
    nomes = {
        'forca': 'Força', 'destreza': 'Destreza',
        'constituicao': 'Constituição', 'inteligencia': 'Inteligência',
        'sabedoria': 'Sabedoria', 'sorte': 'Sorte'
    }
    for k, v in p.attributes.items():
        print(f'{nomes[k]}: {v}')
    print(f'📈 Pontos disponíveis: {p.attribute_points}')

def distribuir_atributos(p):
    while p.attribute_points > 0:
        mostrar_atributos(p)
        print('0. Sair')
        op = input('Atributo para aumentar: ').strip().lower()
        mapa = {
            '1': 'forca', '2': 'destreza', '3': 'constituicao',
            '4': 'inteligencia', '5': 'sabedoria', '6': 'sorte',
            'forca': 'forca', 'destreza': 'destreza',
            'constituicao': 'constituicao', 'inteligencia': 'inteligencia',
            'sabedoria': 'sabedoria', 'sorte': 'sorte'
        }
        if op == '0':
            break
        if op in mapa:
            p.attributes[mapa[op]] += 1
            p.attribute_points -= 1
            recalcular_estatisticas(p)
            print(f'✅ {mapa[op].capitalize()} aumentada!')
        else:
            print('❌ Atributo inválido.')

def unlock_skill(p, skill_name):
    if skill_name in SKILL_DEFS and skill_name not in p.known_skills:
        p.known_skills.append(skill_name)
        p.skills.append({
            'nome': skill_name,
            'custo': SKILL_DEFS[skill_name]['custo']
        })
        print(f'✨ Nova habilidade desbloqueada: {skill_name}!')

def skill_tree_menu(p):
    print('\n════════ ÁRVORE DE HABILIDADES ════════')
    unlocked = False
    for base, options in SKILL_TREE.items():
        if base in p.known_skills:
            for skill_name, level_required in options:
                status = 'DESBLOQUEADA' if skill_name in p.known_skills else f'Lv {level_required}'
                print(f'{base} → {skill_name}: {status}')
                if skill_name not in p.known_skills and p.level >= level_required:
                    ans = input(f'Desbloquear {skill_name}? (s/n) ').lower()
                    if ans == 's':
                        unlock_skill(p, skill_name)
                        unlocked = True
    if not unlocked:
        print('Nenhuma habilidade nova disponível.')

def add_status(p, name, turns=None):
    definition = STATUS_DEFS.get(name)
    if not definition:
        return
    duration = turns or definition['turns']
    for effect in p.status_effects:
        if effect['name'] == name:
            effect['turns'] = max(effect['turns'], duration)
            return
    p.status_effects.append({'name': name, 'turns': duration})

def process_player_status(p):
    skip_turn = False
    for effect in list(p.status_effects):
        name = effect['name']
        definition = STATUS_DEFS.get(name, {})
        damage = definition.get('damage', 0)
        if damage:
            p.health = max(0, p.health - damage)
            print(f'☠️ {name.capitalize()} causa {damage} de dano!')
        if definition.get('skip'):
            skip_turn = True
            print('😵 Você está atordoado e perdeu o turno!')
        effect['turns'] -= 1
        if effect['turns'] <= 0:
            p.status_effects.remove(effect)
            print(f'✨ Efeito {name} terminou.')
    return skip_turn

def crit_multiplier(p):
    return 2.0 if random.uniform(0, 100) < p.crit_chance else 1.0

def calculate_player_damage(p, base, attribute='forca'):
    value = base + p.attributes.get(attribute, 0) * 2
    for effect in p.status_effects:
        if effect['name'] == 'fúria':
            value = int(value * 1.5)
    multiplier = crit_multiplier(p)
    if multiplier > 1:
        print('💥 ACERTO CRÍTICO!')
    return max(1, int(value * multiplier))

def boss_phase_damage_multiplier(hp, max_hp):
    ratio = hp / max_hp
    if ratio <= 0.25:
        return 1.5
    if ratio <= 0.50:
        return 1.25
    return 1.0

#===========================================
#------ COMBATE (COM DEFESA ADAPTADA) ------
#===========================================
 
def aplicar_encantamentos_armor(armadura, dano_reduzido, player):
    # Aplica efeitos extras de encantamentos
    if not armadura:
        return dano_reduzido
    if 'vida' in armadura.get('enchantments', []):
        # chance de curar quando toma dano
        if random.randint(1,100) <= 20:

            cura = min(player.max_health - player.health, 10)
            player.health += cura
            print(f'✨ Encantamento de Vida cura +{cura} HP!')
    if 'espinhos_plus' in armadura.get('enchantments', []):
        if random.randint(1,100) <= 25:
            print('💥 Encantamento de Espinhos causa dano de retorno!')
            # does not alter incoming damage, but will be handled as effect elsewhere
    if 'fogo' in armadura.get('enchantments', []):
                             # proteção extra já foi aplicada via defesa stat
        pass
    return dano_reduzido
def calcular_defesa_integrada(dano_inimigo, player):
    # [SISTEMA DE ARMADURA] - Efeitos especias, dano, defesa
    if not player.armor:
        return dano_inimigo
    armadura = player.armor
    if armadura['durabilidade'] <= 0:
        print(f'⚠️ Sua {armadura["nome"]} está em pedaços!')
        return dano_inimigo

    dano_reduzido = max(0, dano_inimigo - armadura['defesa'])
    desgaste = max(1, int(dano_inimigo * 0.1))
    armadura['durabilidade'] = max(0, armadura['durabilidade'] - desgaste) 
    efeito_ativado = False
    if armadura.get('efeito_especial') == 'sede_de_sangue':
        if random.randint(1, 100) <= 25:
            efeito_ativado = True
            cura = dano_inimigo
            player.health = min(player.max_health, player.health + cura)
            print(f'🦇 {armadura["nome"]} suga a vitalidade! +{cura} HP!')
            dano_reduzido = 0

    elif armadura.get('efeito_especial') == 'espinhos_caoticos':
        if random.randint(1, 100) <= 20:
            efeito_ativado = True
            print(f'💥 {armadura["nome"]} reflete parte do ataque!')
            dano_reduzido = int(dano_reduzido / 2) 
    if not efeito_ativado:
        print(f'⚔️ Defesa: {armadura["defesa"]} | Dano final: {dano_reduzido}') 
    # apply enchantments effects
    dano_reduzido = aplicar_encantamentos_armor(armadura, dano_reduzido, player)
    return dano_reduzido
def spawn_enemy(floor):
    # choose enemy type and scale with floor
    base = random.choice(ENEMY_TYPES)
    name = base['name']
    hp = base['hp_base'] + floor * 3
    dmg_min, dmg_max = base['dmg_base']
    dmg_range = (dmg_min + floor//4, dmg_max + floor//3)
    return {'name': name, 'hp': hp, 'dmg_range': dmg_range, 'drop': base.get('drop')}
def combat(p, enemy, hp, dmg_range, boss=False):
    enemy_name = enemy if isinstance(enemy, str) else enemy.get('name', str(enemy))
    max_hp = hp
    phase_announced = set()

    if boss:
        slow_print(f'🔥 {enemy_name}')

    while hp > 0 and p.health > 0:
        print(f'\n{enemy_name} HP:{hp}/{max_hp} | Player HP:{p.health}/{p.max_health}')

        # Bosses possuem fases de 50% e 25%.
        if boss:
            ratio = hp / max_hp
            if ratio <= 0.50 and 50 not in phase_announced:
                phase_announced.add(50)
                print(f'⚠️ {enemy_name} entrou na FASE 2! Dano aumentado!')
            if ratio <= 0.25 and 25 not in phase_announced:
                phase_announced.add(25)
                print(f'☠️ {enemy_name} entrou na FASE FINAL! Dano muito aumentado!')

        if process_player_status(p):
            if p.health <= 0:
                return False
            # Mesmo perdendo o turno, o inimigo ainda pode atacar.
            raw_dmg = random.randint(*dmg_range)
            if boss:
                raw_dmg = int(raw_dmg * boss_phase_damage_multiplier(hp, max_hp))
            final_dmg = calcular_defesa_integrada(raw_dmg, p)
            p.health -= final_dmg
            continue

        print('1.Atacar 2.Habilidades 3.Poção 4.Defender 5.Técnicas 6.Fugir')
        c = input('> ')
        extra_defense = 0

        if c == '1':
            base = random.randint(8, 18) + p.weapon_level * 2
            dmg = calculate_player_damage(p, base, 'forca')
            hp -= dmg
            print(f'⚔️ Você causou {dmg} de dano!')

            if p.pet:
                pet_dmg = p.pet.assist_damage(p.level)
                print(f'🐾 {p.pet.name} ajuda! +{pet_dmg} dano')
                hp -= pet_dmg

        elif c == '2':
            print('\n✨ HABILIDADES')
            for i, s in enumerate(p.skills, 1):
                print(f'{i}. {s["nome"]} ({s["custo"]} mana)')
            try:
                idx = int(input('Escolha: ')) - 1
                skill = p.skills[idx]
                definition = SKILL_DEFS.get(skill['nome'], SKILL_DEFS['Golpe de Mana'])

                if p.mana >= skill['custo']:
                    p.mana -= skill['custo']
                    damage = calculate_player_damage(
                        p,
                        definition['dano'] + p.level * 2,
                        definition['escala']
                    )
                    hp -= damage
                    print(f'✨ {skill["nome"]} causou {damage} de dano!')

                    if skill['nome'] == 'Escudo Solar':
                        heal = min(p.max_health - p.health, 15 + p.level * 2)
                        p.health += heal
                        print(f'☀️ Você recuperou {heal} HP!')

                    elif skill['nome'] == 'Golpe Sagrado':
                        heal = min(p.max_health - p.health, 8 + p.level)
                        p.health += heal
                        print(f'✝️ Luz sagrada cura {heal} HP!')

                    elif skill['nome'] == 'Ataque Furtivo':
                        add_status(p, 'fúria', 1)

                else:
                    print('❌ Mana insuficiente!')
            except (ValueError, IndexError):
                print('❌ Habilidade inválida.')

        elif c == '3' and p.inventory['pocoes'] > 0:
            p.inventory['pocoes'] -= 1
            heal = min(p.max_health - p.health, 50)
            p.health += heal
            print(f'🧪 Você recuperou {heal} HP!')

        elif c == '4':
            extra_defense = random.randint(8, 18)
            print(f'🛡️ Você se prepara para defender! +{extra_defense} defesa.')

        elif c == '5':
            print('1. Fúria (+50% dano por 3 turnos)')
            print('2. Purificar (remove efeitos negativos)')
            tech = input('> ')
            if tech == '1':
                add_status(p, 'fúria', 3)
                print('🔥 Você entrou em estado de FÚRIA!')
            elif tech == '2':
                before = len(p.status_effects)
                p.status_effects = [
                    e for e in p.status_effects if e['name'] == 'fúria'
                ]
                print(f'✨ {before - len(p.status_effects)} efeitos negativos removidos!')

        elif c == '6' and not boss:
            if random.random() < 0.5:
                print('🏃 Você conseguiu fugir!')
                return 'fled'
            print('❌ Você não conseguiu fugir!')

        else:
            print('❌ Ação inválida.')

        # Inimigo ataca se ainda estiver vivo.
        if hp > 0:
            raw_dmg = random.randint(*dmg_range)

            # Boss fica mais perigoso nas fases seguintes.
            if boss:
                raw_dmg = int(raw_dmg * boss_phase_damage_multiplier(hp, max_hp))

            # Alguns inimigos têm efeitos especiais.
            if isinstance(enemy, dict):
                if enemy_name == 'Aranha Enorme' and random.randint(1, 100) <= 20:
                    add_status(p, 'veneno')
                    print('🕷️ A Aranha Enorme envenenou você!')
                elif enemy_name == 'Trovão Errante' and random.randint(1, 100) <= 15:
                    add_status(p, 'atordoado')
                    print('⚡ O Trovão Errante deixou você atordoado!')

            final_dmg = max(0, calcular_defesa_integrada(raw_dmg, p) - extra_defense)

            # Retaliação do encantamento acontece uma única vez.
            if p.armor and 'espinhos_plus' in p.armor.get('enchantments', []):
                if random.randint(1, 100) <= 25:
                    retaliation = max(1, int(raw_dmg * 0.25))
                    hp -= retaliation
                    print(f'💥 Espinhos+ causa {retaliation} de dano de retorno!')

            p.health -= final_dmg
            print(f'💢 Você sofreu {final_dmg} de dano!')

    if p.health <= 0:
        print('💀 Você foi derrotado!')
        return False

    if isinstance(enemy, dict):
        drop = enemy.get('drop')
        if drop:
            p.add_drop(drop, 1)
            print(f'🎁 Obteve drop: {drop}')
            p.check_quests_progress(drop_item=drop)
        p.check_quests_progress(enemy_name=enemy_name)
    else:
        p.check_quests_progress(enemy_name=enemy_name)

    if boss:
        p.inventory['cabecas_boss'].append(enemy_name)
        p.check_quests_progress(boss_killed=True)

    p.gain_exp(100 if boss else 30)

    if 'first_kill' not in p.achievements:
        unlock_achievement(p, 'first_kill')

    return True

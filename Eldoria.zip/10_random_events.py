#========================
#------ RANDOM EVENTS ---
#========================
 
def dungeon_random_event(p, floor):

    r = random.randint(1, 100)

    if r <= 15:

        # merchant

        slow_print('🧑‍🌾 Um mercador perdido aparece...')

        print('1. Comprar Poção (10g) | 2. Comprar Reparo Rápido (30g) | 3. Nada')

        c = input('> ')

        if c == '1' and p.money >= 10:

            p.money -= 10

            p.inventory['pocoes'] += 1

        elif c == '2' and p.money >= 30 and p.armor:

            p.money -= 30

            p.armor['durabilidade'] = min(p.armor['max_durabilidade'], p.armor['durabilidade'] + 40)

    elif r <= 30:

        # trap

        slow_print('⚠️ Armadilha! Alguns espinhos saem do chão...')

        dmg = random.randint(5, 15)

        final = calcular_defesa_integrada(dmg, p)

        p.health -= max(0, final)

        print(f'Você sofreu {max(0, final)} de dano na armadilha.')

    elif r <= 45:

        # shrine

        slow_print('🔮 Um santuário antigo... você sente uma presença benevolente.')

        if random.randint(1,100) <= 50:

            p.mana = min(p.max_mana, p.mana + 20)

            print('✨ Mana restaurada parcialmente.')

        else:

            p.add_drop('Relíquia Antiga', 1)

            print('🎁 Você encontrou uma Relíquia Antiga!')

            unlock_achievement(p, 'found_treasure')

    else:

        # lore scroll

        slow_print(random.choice(LORE_SCROLLS))

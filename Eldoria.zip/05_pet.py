#========================
#------ PET / COMPANION -
#========================
 
class Pet:

    def __init__(self, name, kind='Familiar'):
        self.name = name
        self.kind = kind
        self.level = 1
        self.exp = 0
 
    def assist_damage(self, player_level):
        # Pet deals small damage based on level
        return random.randint(2, 5) + self.level + player_level
    def gain_exp(self, amount):
        self.exp += amount
        while self.exp >= 50 * self.level:
            self.exp -= 50 * self.level
            self.level += 1
            print(f'🐾 {self.name} subiu para Nív. {self.level}!')

# Eldoria - entry point
# This loader executes the separated source files in the original order,
# preserving the shared global namespace of the original single-file game.
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MODULES = [
    '01_save_system.py',
    '02_lore.py',
    '03_game_data.py',
    '04_utils.py',
    '05_pet.py',
    '06_classes.py',
    '07_player.py',
    '08_village.py',
    '09_combat.py',
    '10_random_events.py',
    '11_dungeon.py',
    '12_achievements.py',
    '13_main.py',
]

namespace = globals()
for module_name in MODULES:
    path = BASE_DIR / module_name
    source = path.read_text(encoding='utf-8')
    code = compile(source, str(path), 'exec')
    exec(code, namespace, namespace)

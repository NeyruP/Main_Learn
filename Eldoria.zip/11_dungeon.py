#========================
#------ DUNGEON -------
#========================
 
def dungeon(p):

    floor = 1

    while floor <= 18:

        print(f'\n--- FLOOR {floor} ---')

        act = input('1.Avançar 2.Descansar 3.Sair ')

        if act == '1':

            # random event chance before encounters

            if random.randint(1,100) <= 25:

                dungeon_random_event(p, floor)
 
            # [SISTEMA DE ARMADURA] - Garantido no 6

            if floor == 6 and not p.armor:

                found = {'nome': 'Cota de Malha Velha', 'defesa': 2, 'durabilidade': 50, 'max_durabilidade': 80, 'efeito_especial': None, 'level': 1, 'enchantments': []}

                slow_print(f'🎁 Você encontrou um baú no andar 6! Contém uma {found["nome"]}.')

                if input('Equipar? 1.Sim 2.Não > ') == '1':

                    p.armor = found

                    print('🛡️ Armadura equipada!')

                    unlock_achievement(p, 'found_treasure')
 
            r = random.randint(1, 100)

            if r < 40:

                # spawn a varied enemy

                e = spawn_enemy(floor)

                combat(p, e, e['hp'], e['dmg_range'])

            elif r < 70:

                slow_print(random.choice(LORE_SCROLLS))

            else:

                boss = BOSS_LORE.get(floor)

                if boss:

                    name, talk = boss

                    slow_print(f'{name}: {talk}')

                    if combat(p, name, 120 + floor * 20, (10, 20 + floor), True): floor += 1

                    else: break

                else: floor += 1

        elif act == '2':

            p.mana = p.max_mana

            print('✨ Mana restaurada!')

        elif act == '3': break

#========================
#------ UTIL ----------
#========================
 
def slow_print(text, delay=0.08):

    for c in text:

        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write('\n')
    sys.stdout.flush()
    time.sleep(0.01)

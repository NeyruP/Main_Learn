#========================
#------ ACHIEVEMENTS ---
#========================
 
def unlock_achievement(p, key):

    if key in ACHIEVEMENT_DEFS and key not in p.achievements:

        p.achievements[key] = ACHIEVEMENT_DEFS[key]

        print(f'🏆 Conquista desbloqueada: {ACHIEVEMENT_DEFS[key]["title"]} - {ACHIEVEMENT_DEFS[key]["desc"]}')
 
def show_achievements(p):

    slow_print('🏅 Conquistas:')

    if not p.achievements:

        print('Nenhuma conquista ainda.')

    for k, v in p.achievements.items():

        print(f'- {v["title"]}: {v["desc"]}')

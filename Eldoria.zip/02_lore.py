#========================
#------ LORE ----------
#========================
 
LORE_INTRO = [

    '--- AS CRÔNICAS DE ELDORIA ---',
    'O sol não brilha mais como antes...',
    'A Calamidade desperta nas profundezas...',
    'Eldoria aguarda um Sem-Nome.'

]
 
LORE_SCROLLS = [

    'O 18º andar não deveria existir.',
    'A luz aqui abaixo apodrece.',
    'A capital foi arrancada do mundo.',

]
 
BOSS_LORE = {

    1: ('Korg, o Cobrador', 'Você entrou sem pagar.'),
    2: ('Sombra Faminta', 'Eu sinto seu medo.'),
    9: ('Quimera Instável', 'Múltiplas almas, um corpo.'),
    15: ('Arquiduque do Pavor', 'Você não deveria ter chegado aqui.'),
    18: ('CALAMIDADE', 'O fim já começou.')

}

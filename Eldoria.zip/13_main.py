#========================
#------ MAIN -----------
#========================
 
def main():

    for l in LORE_INTRO: slow_print(l)

    choice = input('1.Novo 2.Load 3.Importar Save > ')

    p = None
    
    if choice == '2':
        p = load_game()
    elif choice == '3':
        # Import save from file
        filename = input('Nome do arquivo de save para importar (ex: save_Hero.pkl): ')
        p = load_game(filename)

    if not p:
        nome = input('Nome: ')
        classe = escolher_classe()
        p = Player(nome, classe)
        recalcular_estatisticas(p)
        print(f'✨ Você escolheu a classe {classe}!')
 
    while p.health > 0:

        p.display_status()

        print('\n1.Ferreiro 2.Alquimista 3.Guilda 4.Dungeon 5.Save 6.Sair 7.Companheiro 8.Conquistas 9.Download Save 10.Atributos 11.Habilidades')

        op = input('> ')

        if op == '1': 
            blacksmith(p)

        elif op == '2': 
            alchemist(p)

        elif op == '3': 
            guild(p)

        elif op == '4': 
            dungeon(p)

        elif op == '5': 
            filename = save_game(p)
            if filename:
                print(f'✅ Save salvo em: {filename}')

        elif op == '6': 
            break

        elif op == '7': 
            companion_menu(p)

        elif op == '8': 
            show_achievements(p)

        elif op == '10':
            distribuir_atributos(p)

        elif op == '11':
            skill_tree_menu(p)

        elif op == '9':
            # Download the save file
            filename = f'save_{p.name}.pkl'
            if os.path.exists(filename):
                serve_file_for_download(filename)
            else:
                print('❌ Nenhum save para fazer download. Salve primeiro (opção 5).')
 
if __name__ == '__main__':

    main()

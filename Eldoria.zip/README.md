# Eldoria — Código separado

O código foi separado por responsabilidade, mantendo a ordem e a lógica do arquivo original.

## Estrutura
- main.py — inicializador
- 01_save_system.py — save/load e download
- 02_lore.py — lore e bosses
- 03_game_data.py — inimigos, quests e conquistas
- 04_utils.py — utilidades
- 05_pet.py — companheiro
- 06_classes.py — classes, atributos, skills e status
- 07_player.py — jogador
- 08_village.py — vila
- 09_combat.py — combate
- 10_random_events.py — eventos aleatórios
- 11_dungeon.py — dungeon
- 12_achievements.py — conquistas
- 13_main.py — menu principal

## Como executar
```bash
python main.py
```

O arquivo original fica preservado separadamente no ZIP como `eldoria_original.py`.

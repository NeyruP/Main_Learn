#========================
#------ SAVE SYSTEM -----
#========================

def player_to_dict(player):
    # Convert player to dict, handling Pet serialization
    data = player.__dict__.copy()
    
    # Convert Pet object to dict for safe serialization
    if data.get('pet') and hasattr(data['pet'], '__dict__'):
        pet_obj = data['pet']
        data['pet'] = {
            'name': pet_obj.name,
            'kind': pet_obj.kind,
            'level': pet_obj.level,
            'exp': pet_obj.exp,
            '_is_pet': True
        }
    
    return data

def dict_to_player(data):
    try:
        if not isinstance(data, dict) or 'name' not in data:
            raise ValueError('Save data não tem formato esperado.')
        
        p = Player(data.get('name', 'Desconhecido'))

        # Safe attribute restoration
        allowed_extra = {'armor', 'inventory', 'skills', '_save_version', 'pet'}
        for k, v in data.items():
            if hasattr(p, k) or k in allowed_extra:
                # Handle Pet deserialization
                if k == 'pet' and isinstance(v, dict) and v.get('_is_pet'):
                    pet = Pet(v.get('name', 'Companheiro'))
                    pet.kind = v.get('kind', 'Familiar')
                    pet.level = v.get('level', 1)
                    pet.exp = v.get('exp', 0)
                    setattr(p, k, pet)
                # Handle armor dict with defaults
                elif k == 'armor' and v is not None:
                    armor = v.copy() if isinstance(v, dict) else None
                    if armor:
                        # Ensure armor has all required keys
                        armor.setdefault('nome', 'Armadura Desconhecida')
                        armor.setdefault('defesa', 0)
                        armor.setdefault('durabilidade', 100)
                        armor.setdefault('max_durabilidade', 100)
                        armor.setdefault('efeito_especial', None)
                        armor.setdefault('level', 1)
                        armor.setdefault('enchantments', [])
                    setattr(p, k, armor)
                else:
                    setattr(p, k, v)
        
        # Compatibilidade com saves antigos
        p.class_name = getattr(p, 'class_name', 'Guerreiro')
        p.attributes = getattr(p, 'attributes', {
            'forca': 5, 'destreza': 5, 'constituicao': 5,
            'inteligencia': 5, 'sabedoria': 5, 'sorte': 5
        })
        p.attribute_points = getattr(p, 'attribute_points', 0)
        p.crit_chance = getattr(p, 'crit_chance', 5)
        p.status_effects = getattr(p, 'status_effects', [])
        p.skill_tree = getattr(p, 'skill_tree', [])
        p.known_skills = getattr(p, 'known_skills', [] )
        p.gold_bonus = getattr(p, 'gold_bonus', 0)
        p.dungeon_floor_reached = getattr(p, 'dungeon_floor_reached', 0)
        recalcular_estatisticas(p)
        return p
    except Exception as e:
        print('❌ Erro ao recriar jogador:', e)
        return None

# --- improved pickle save/load with atomic write and backups ---
def save_game(player, filename=None):
    """Save game with atomic writes and backup."""
    filename = filename or f'save_{player.name}.pkl'
    tmp = filename + '.tmp'
    backup = filename + '.bak'

    data = player_to_dict(player)
    data['_save_version'] = 2  # bump if you change save structure later

    try:
        # write to temp file first
        with open(tmp, 'wb') as f:
            pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)

        # create a backup of existing save if present
        if os.path.exists(filename):
            try:
                shutil.copy2(filename, backup)
            except Exception as e:
                print(f'⚠️ Aviso: não foi possível criar backup: {e}')

        # atomic replace
        os.replace(tmp, filename)
        print('💾 Jogo salvo com sucesso!')
        return filename
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        print('❌ Erro ao salvar:', e)
        return None

def load_game(filename=None):
    """Load game from save file with backup recovery."""
    candidate = None
    
    if filename:
        candidate = filename
    else:
        # Find save_*.pkl and save.pkl
        saves = sorted(glob.glob('save_*.pkl') + glob.glob('save.pkl'))
        if len(saves) == 0:
            print('❌ Nenhum save encontrado no diretório atual.')
            return None
        elif len(saves) == 1:
            candidate = saves[0]
            print(f'🔎 Save encontrado: {candidate}')
        else:
            print('🔎 Saves encontrados:')
            for i, s in enumerate(saves, start=1):
                print(f'{i}. {s}')
            try:
                idx = int(input('Escolha o número do save para carregar (0 cancelar): '))
                if idx == 0:
                    return None
                if 1 <= idx <= len(saves):
                    candidate = saves[idx-1]
                else:
                    print('❌ Número inválido.')
                    return None
            except (ValueError, IndexError):
                print('❌ Entrada inválida. Cancelando load.')
                return None

    if not candidate:
        return None

    try:
        with open(candidate, 'rb') as f:
            data = pickle.load(f)
        
        # validate basic shape
        if not isinstance(data, dict) or 'name' not in data:
            print('❌ Save inválido ou formato incorreto.')
            return None
        
        p = dict_to_player(data)
        if p is None:
            print('❌ Falha ao reconstruir o jogador a partir do save.')
            return None
        
        print(f'📂 Save carregado: {candidate}')
        return p
        
    except FileNotFoundError:
        print(f'❌ Arquivo de save não encontrado: {candidate}')
        return None
        
    except (pickle.UnpicklingError, EOFError) as e:
        print(f'❌ Save corrompido: {e}')
        
        # try backup recovery
        backup = candidate + '.bak'
        if os.path.exists(backup):
            try:
                with open(backup, 'rb') as f:
                    data = pickle.load(f)
                print('♻️ Backup encontrado — carregando backup...')
                p = dict_to_player(data)
                if p:
                    try:
                        shutil.copy2(backup, candidate)
                        print('♻️ Backup restaurado como save principal.')
                    except Exception as restore_err:
                        print(f'⚠️ Não foi possível restaurar backup: {restore_err}')
                    return p
            except Exception as backup_err:
                print(f'❌ Backup também corrompido: {backup_err}')
        return None
        
    except Exception as e:
        print(f'❌ Erro ao carregar save: {e}')
        return None

# --- serve a single file on localhost and open browser for download ---
def serve_file_for_download(filepath, host='127.0.0.1', port=0, timeout=60):
    """Serve save file via HTTP for download."""
    if not os.path.exists(filepath):
        print(f'❌ Arquivo de save não encontrado: {filepath}')
        return

    tempdir = tempfile.mkdtemp(prefix='eldoria_save_')
    filename = os.path.basename(filepath)
    target = os.path.join(tempdir, filename)
    
    try:
        shutil.copy2(filepath, target)
    except Exception as e:
        print(f'❌ Falha ao preparar arquivo para download: {e}')
        try:
            shutil.rmtree(tempdir)
        except Exception:
            pass
        return

    prev_cwd = os.getcwd()
    os.chdir(tempdir)

    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # silence logs

    httpd = None
    try:
        httpd = socketserver.TCPServer((host, port), QuietHandler)
        assigned_port = httpd.server_address[1]
        url = f'http://{host}:{assigned_port}/{filename}'

        # Start server in background
        def run_server():
            try:
                httpd.serve_forever()
            except Exception as server_err:
                print(f'⚠️ Erro no servidor: {server_err}')

        t = threading.Thread(target=run_server, daemon=True)
        t.start()

        try:
            print(f'🔗 Abrindo navegador para baixar: {url}')
            webbrowser.open(url)
            print(f'⏳ Servindo o save por até {timeout}s. Pressione Enter para parar antes.')

            # Cross-platform wait for Enter or timeout
            if os.name == 'nt':
                # Windows: input() blocks and works reliably
                try:
                    input()
                except (KeyboardInterrupt, EOFError):
                    pass
            else:
                # Unix: use select with timeout to listen for stdin
                try:
                    rlist, _, _ = select.select([sys.stdin], [], [], timeout)
                    if rlist:
                        try:
                            _ = sys.stdin.readline()
                        except Exception:
                            pass
                except Exception:
                    # fallback to blocking input if select fails
                    try:
                        input()
                    except (KeyboardInterrupt, EOFError):
                        pass
        finally:
            try:
                httpd.shutdown()
                httpd.server_close()
            except Exception:
                pass
            t.join(timeout=1)

    except Exception as e:
        print(f'❌ Erro ao iniciar servidor de download: {e}')
    finally:
        os.chdir(prev_cwd)
        try:
            shutil.rmtree(tempdir)
        except Exception as cleanup_err:
            print(f'⚠️ Aviso ao limpar arquivos temporários: {cleanup_err}')
        print('✅ Servidor parado.')

#========================
#------ GAME DATA ------
#========================
 
ENEMY_TYPES = [

    {'name': 'Lobo das Sombras', 'hp_base': 40, 'dmg_base': (5, 10), 'drop': 'Pele de Lobo'},
    {'name': 'Goblin Sarnento', 'hp_base': 30, 'dmg_base': (3, 8), 'drop': 'Dente de Goblin'},
    {'name': 'Aranha Enorme', 'hp_base': 35, 'dmg_base': (4, 9), 'drop': 'Veneno Grosso'},
    {'name': 'Trovão Errante', 'hp_base': 45, 'dmg_base': (6, 12), 'drop': 'Fragmento de Trovão'},

]
 
QUESTS = [

    {'id': 1, 'titulo': 'Caçar Lobos', 'descricao': 'Derrote 3 Lobos das Sombras.', 'target': {'enemy_name': 'Lobo das Sombras', 'count': 3}, 'recompensa_money': 120, 'recompensa_exp': 60},
    {'id': 2, 'titulo': 'Coletar Veneno', 'descricao': 'Traga 2 Venenos Grossos.', 'target': {'item': 'Veneno Grosso', 'count': 2}, 'recompensa_money': 80, 'recompensa_exp': 40},
    {'id': 3, 'titulo': 'Troféu do Chefe', 'descricao': 'Derrote um chefe e entregue sua cabeça.', 'target': {'boss': True, 'count': 1}, 'recompensa_money': 300, 'recompensa_exp': 200},

]
 
ACHIEVEMENT_DEFS = {

    'first_kill': {'title': 'Iniciante', 'desc': 'Derrote seu primeiro inimigo.'},
    'first_pet': {'title': 'Amigo Fiel', 'desc': 'Adote um companheiro.'},
    'blacksmith_upgraded': {'title': 'Forjado', 'desc': 'Melhore algo no ferreiro.'},
    'found_treasure': {'title': 'Explorador', 'desc': 'Encontre um baú no dungeon.'}

}
